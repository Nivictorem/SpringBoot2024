package ru.pavlov.CourseProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
