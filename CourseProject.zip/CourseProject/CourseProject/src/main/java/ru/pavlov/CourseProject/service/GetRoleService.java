package ru.pavlov.CourseProject.service;

public interface GetRoleService {
    String getRoleCurrentUser();
}
