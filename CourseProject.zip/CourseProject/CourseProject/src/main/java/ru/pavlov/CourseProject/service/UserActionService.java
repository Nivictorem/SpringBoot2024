package ru.pavlov.CourseProject.service;

public interface UserActionService {
    void setUserAction(String userAction);
}
