package ru.pavlov.CourseProject.service;

public interface GetUsernameService {
    String getusername();
}
